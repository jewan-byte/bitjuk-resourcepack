#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    // DragonEgg day counter: boss bar title drawn in colour #1325D3 is moved to the
    // top-right corner, scaled 2x and painted white. Its shadow (#04093A, colour/4) is hidden.
    vec3 c255 = round(Color.rgb * 255.0);
    bool hud = c255 == vec3(19.0, 37.0, 211.0);
    bool hudShadow = c255 == vec3(4.0, 9.0, 52.0);
    if ((hud || hudShadow) && ProjMat[3][3] == 1.0) {
        float px = ProjMat[0][0];      // NDC per GUI pixel, x
        float py = -ProjMat[1][1];     // NDC per GUI pixel, y (GUI y points down)
        float S = 2.0;                 // scale
        float halfW = 21.0;            // the text is padded to 42 GUI px
        float titleTop = 1.0 - 3.0 * py;   // boss bar titles start 3 px below the top
        gl_Position.x = (1.0 - 5.0 * px - S * halfW * px) + gl_Position.x * S;
        gl_Position.y = (1.0 - 4.0 * py) + (gl_Position.y - titleTop) * S;
        vertexColor = hud ? vec4(1.0, 1.0, 1.0, Color.a) : vec4(0.0);
    }
#endif
}
